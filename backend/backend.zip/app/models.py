# models.py
from datetime import datetime, date

from sqlalchemy import (
    Column,
    Integer,
    String,
    Float,
    Boolean,
    DateTime,
    Text,
    Date,
    ForeignKey,
)
from sqlalchemy.orm import declarative_base

Base = declarative_base()


class Pet(Base):
    __tablename__ = "pets"

    id = Column(Integer, primary_key=True, index=True)
    user_email = Column(String, index=True, nullable=False)

    name = Column(String, nullable=False)
    species = Column(String, nullable=False)  # "dog" or "cat"
    breed = Column(String, nullable=False)

    age_years = Column(Float, nullable=False)
    weight_kg = Column(Float, nullable=False)

    is_neutered = Column(Boolean, default=False, nullable=False)
    activity_level = Column(String, nullable=False)  # sedentary/moderate/active/very_active

    health_conditions = Column(Text, nullable=True)
    allergies = Column(Text, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)


class ActivityLog(Base):
    __tablename__ = "activity_logs"

    id = Column(Integer, primary_key=True, index=True)
    pet_id = Column(Integer, ForeignKey("pets.id", ondelete="CASCADE"), index=True, nullable=False)

    # Store as DATE so “adjust by day” comparisons work reliably
    activity_date = Column(Date, index=True, nullable=False)

    steps = Column(Integer, default=0, nullable=False)
    active_minutes = Column(Integer, default=0, nullable=False)
    calories_burned = Column(Float, default=0.0, nullable=False)


class NutritionPlan(Base):
    __tablename__ = "nutrition_plans"

    id = Column(Integer, primary_key=True, index=True)
    pet_id = Column(Integer, ForeignKey("pets.id", ondelete="CASCADE"), index=True, nullable=False)

    # Store as DATE to align with daily planning
    plan_date = Column(Date, index=True, default=date.today, nullable=False)

    daily_calories = Column(Float, nullable=False)
    meal_frequency = Column(Integer, nullable=False)
    portion_size_grams = Column(Float, nullable=False)
    food_type = Column(String, nullable=False)  # kibble, wet, raw
    notes = Column(Text, nullable=True)

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    password_hash = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)


class AuthSession(Base):
    __tablename__ = "auth_sessions"

    token = Column(String, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), index=True, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    expires_at = Column(DateTime, nullable=False)
